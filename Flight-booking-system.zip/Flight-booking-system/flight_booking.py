# Airline Reservation System - Assignment 14
# Name: [Your Name]
# Date: [Current Date]

import json
import csv
import os
from datetime import datetime
import random

# Custom Exception for overbooking
class OverbookingError(Exception):
    def __init__(self, message):
        self.message = message
        super().__init__(self.message)

# Passenger Class with encapsulation
class Passenger:
    def __init__(self, passenger_id, name, email, phone, age):
        self.__passenger_id = passenger_id  # Private attribute
        self.__name = name                  # Private attribute
        self.__email = email                # Private attribute
        self.__phone = phone                # Private attribute
        self.__age = age                    # Private attribute
    
    # Getter methods (accessors)
    def get_passenger_id(self):
        return self.__passenger_id
    
    def get_name(self):
        return self.__name
    
    def get_email(self):
        return self.__email
    
    def get_phone(self):
        return self.__phone
    
    def get_age(self):
        return self.__age
    
    # Setter methods
    def set_email(self, email):
        self.__email = email
    
    def set_phone(self, phone):
        self.__phone = phone

# Base Flight Class
class Flight:
    def __init__(self, flight_number, departure, destination, departure_time, total_seats, base_price):
        self.flight_number = flight_number
        self.departure = departure
        self.destination = destination
        self.departure_time = departure_time
        self.total_seats = total_seats
        self.base_price = base_price
        self.seat_map = {}  # Dictionary to store seat allocations
        self.available_seats = list(range(1, total_seats + 1))  # List of available seats
        self.waitlist = []  # Waitlist for passengers
        
    def allocate_seat(self, passenger_id, seat_number=None):
        try:
            if seat_number is None:
                # Auto-assign seat
                if len(self.available_seats) == 0:
                    raise OverbookingError("No seats available on this flight")
                seat_number = self.available_seats[0]
            
            if seat_number not in self.available_seats:
                if seat_number in self.seat_map:
                    raise Exception(f"Seat {seat_number} is already taken")
                else:
                    raise Exception(f"Invalid seat number {seat_number}")
            
            # Assign seat
            self.seat_map[seat_number] = passenger_id
            self.available_seats.remove(seat_number)
            return seat_number
            
        except OverbookingError as e:
            # Add to waitlist
            self.waitlist.append(passenger_id)
            raise e
    
    def cancel_seat(self, seat_number):
        if seat_number in self.seat_map:
            passenger_id = self.seat_map[seat_number]
            del self.seat_map[seat_number]
            self.available_seats.append(seat_number)
            self.available_seats.sort()
            
            # Check waitlist
            if len(self.waitlist) > 0:
                waitlist_passenger = self.waitlist.pop(0)
                self.seat_map[seat_number] = waitlist_passenger
                self.available_seats.remove(seat_number)
                return waitlist_passenger
            
            return None
        else:
            raise Exception("Seat not found or already empty")
    
    def get_final_price(self):
        return self.base_price

# Domestic Flight Class (Inheritance)
class DomesticFlight(Flight):
    def __init__(self, flight_number, departure, destination, departure_time, total_seats, base_price):
        super().__init__(flight_number, departure, destination, departure_time, total_seats, base_price)
        self.flight_type = "Domestic"

# International Flight Class (Inheritance)
class InternationalFlight(Flight):
    def __init__(self, flight_number, departure, destination, departure_time, total_seats, base_price):
        super().__init__(flight_number, departure, destination, departure_time, total_seats, base_price)
        self.flight_type = "International"
        self.international_fee = 150  # Extra fee for international flights
    
    def get_final_price(self):
        return self.base_price + self.international_fee

# Booking Class (Composition)
class Booking:
    def __init__(self, booking_id, passenger, flight, seat_number):
        self.booking_id = booking_id
        self.passenger = passenger  # Composition - Booking has a Passenger
        self.flight = flight        # Composition - Booking has a Flight
        self.seat_number = seat_number
        self.booking_date = datetime.now()
        self.status = "Confirmed"
    
    def get_total_price(self):
        return self.flight.get_final_price()

# Main Airline Reservation System
class AirlineReservationSystem:
    def __init__(self):
        self.flights = {}
        self.passengers = {}
        self.bookings = {}
        self.booking_counter = 1000
        
        # Create directories if they don't exist
        if not os.path.exists('tickets'):
            os.makedirs('tickets')
        if not os.path.exists('manifests'):
            os.makedirs('manifests')
    
    def load_sample_data(self):
        # Load flights from JSON (sample data)
        try:
            sample_flights = [
                {"flight_number": "AI101", "departure": "Delhi", "destination": "Mumbai", 
                 "departure_time": "08:00", "total_seats": 50, "base_price": 5000, "type": "domestic"},
                {"flight_number": "6E202", "departure": "Bangalore", "destination": "Chennai", 
                 "departure_time": "14:30", "total_seats": 45, "base_price": 4500, "type": "domestic"},
                {"flight_number": "AI301", "departure": "Delhi", "destination": "New York", 
                 "departure_time": "02:00", "total_seats": 30, "base_price": 45000, "type": "international"},
                {"flight_number": "EK501", "departure": "Mumbai", "destination": "Dubai", 
                 "departure_time": "18:45", "total_seats": 40, "base_price": 25000, "type": "international"}
            ]
            
            for flight_data in sample_flights:
                if flight_data["type"] == "domestic":
                    flight = DomesticFlight(
                        flight_data["flight_number"],
                        flight_data["departure"],
                        flight_data["destination"],
                        flight_data["departure_time"],
                        flight_data["total_seats"],
                        flight_data["base_price"]
                    )
                else:
                    flight = InternationalFlight(
                        flight_data["flight_number"],
                        flight_data["departure"],
                        flight_data["destination"],
                        flight_data["departure_time"],
                        flight_data["total_seats"],
                        flight_data["base_price"]
                    )
                
                self.flights[flight_data["flight_number"]] = flight
                
        except Exception as e:
            print(f"Error loading flight data: {e}")
        
        # Load passengers from CSV (sample data)
        try:
            sample_passengers = [
                ["P001", "John Doe", "john@email.com", "9876543210", 30],
                ["P002", "Jane Smith", "jane@email.com", "9876543211", 25],
                ["P003", "Raj Kumar", "raj@email.com", "9876543212", 35],
                ["P004", "Priya Sharma", "priya@email.com", "9876543213", 28]
            ]
            
            for passenger_data in sample_passengers:
                passenger = Passenger(
                    passenger_data[0],
                    passenger_data[1],
                    passenger_data[2],
                    passenger_data[3],
                    passenger_data[4]
                )
                self.passengers[passenger_data[0]] = passenger
                
        except Exception as e:
            print(f"Error loading passenger data: {e}")
    
    def create_booking(self, passenger_id, flight_number, seat_number=None):
        try:
            # Validate flight number
            if flight_number not in self.flights:
                raise Exception(f"Invalid flight number: {flight_number}")
            
            # Validate passenger
            if passenger_id not in self.passengers:
                raise Exception(f"Passenger not found: {passenger_id}")
            
            flight = self.flights[flight_number]
            passenger = self.passengers[passenger_id]
            
            # Try to allocate seat
            try:
                assigned_seat = flight.allocate_seat(passenger_id, seat_number)
            except OverbookingError as e:
                print(f"Flight is full. Passenger added to waitlist.")
                return None
            
            # Create booking
            booking_id = f"BK{self.booking_counter}"
            self.booking_counter += 1
            
            booking = Booking(booking_id, passenger, flight, assigned_seat)
            self.bookings[booking_id] = booking
            
            # Generate boarding pass
            self.generate_boarding_pass(booking)
            
            # Log booking
            self.log_booking(booking)
            
            print(f"Booking successful! Booking ID: {booking_id}, Seat: {assigned_seat}")
            return booking_id
            
        except Exception as e:
            print(f"Booking failed: {e}")
            return None
    
    def cancel_booking(self, booking_id):
        try:
            if booking_id not in self.bookings:
                raise Exception("Booking not found")
            
            booking = self.bookings[booking_id]
            flight = booking.flight
            
            # Cancel seat and check waitlist
            waitlist_passenger = flight.cancel_seat(booking.seat_number)
            
            # Update booking status
            booking.status = "Cancelled"
            
            # If someone from waitlist got the seat, create new booking for them
            if waitlist_passenger:
                # Find passenger object
                for p_id, passenger in self.passengers.items():
                    if p_id == waitlist_passenger:
                        new_booking_id = self.create_booking(p_id, flight.flight_number, booking.seat_number)
                        print(f"Waitlist passenger {passenger.get_name()} has been assigned seat {booking.seat_number}")
                        break
            
            print(f"Booking {booking_id} cancelled successfully")
            
        except Exception as e:
            print(f"Cancellation failed: {e}")
    
    def generate_boarding_pass(self, booking):
        try:
            filename = f"tickets/{booking.booking_id}.txt"
            with open(filename, 'w') as f:
                f.write("="*50 + "\n")
                f.write("           BOARDING PASS\n")
                f.write("="*50 + "\n")
                f.write(f"Booking ID: {booking.booking_id}\n")
                f.write(f"Passenger: {booking.passenger.get_name()}\n")
                f.write(f"Flight: {booking.flight.flight_number}\n")
                f.write(f"From: {booking.flight.departure}\n")
                f.write(f"To: {booking.flight.destination}\n")
                f.write(f"Departure: {booking.flight.departure_time}\n")
                f.write(f"Seat: {booking.seat_number}\n")
                f.write(f"Price: Rs. {booking.get_total_price()}\n")
                f.write(f"Date: {booking.booking_date.strftime('%Y-%m-%d %H:%M')}\n")
                f.write("="*50 + "\n")
                
        except Exception as e:
            print(f"Error generating boarding pass: {e}")
    
    def log_booking(self, booking):
        try:
            with open('bookings.log', 'a') as f:
                log_entry = f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - "
                log_entry += f"Booking {booking.booking_id} - "
                log_entry += f"Passenger: {booking.passenger.get_name()} - "
                log_entry += f"Flight: {booking.flight.flight_number} - "
                log_entry += f"Seat: {booking.seat_number} - "
                log_entry += f"Price: Rs.{booking.get_total_price()}\n"
                f.write(log_entry)
                
        except Exception as e:
            print(f"Error logging booking: {e}")
    
    def generate_flight_manifest(self, flight_number):
        try:
            if flight_number not in self.flights:
                raise Exception("Invalid flight number")
            
            flight = self.flights[flight_number]
            filename = f"manifests/manifest_{flight_number}.txt"
            
            with open(filename, 'w') as f:
                f.write("="*60 + "\n")
                f.write(f"        FLIGHT MANIFEST - {flight_number}\n")
                f.write("="*60 + "\n")
                f.write(f"Flight: {flight.departure} to {flight.destination}\n")
                f.write(f"Departure Time: {flight.departure_time}\n")
                f.write(f"Total Seats: {flight.total_seats}\n")
                f.write(f"Occupied Seats: {len(flight.seat_map)}\n")
                f.write(f"Available Seats: {len(flight.available_seats)}\n")
                f.write("-"*60 + "\n")
                f.write("PASSENGER LIST:\n")
                f.write("-"*60 + "\n")
                
                for seat_num, passenger_id in sorted(flight.seat_map.items()):
                    passenger = self.passengers[passenger_id]
                    f.write(f"Seat {seat_num:2d}: {passenger.get_name()}\n")
                
                if flight.waitlist:
                    f.write("\nWAITLIST:\n")
                    f.write("-"*60 + "\n")
                    for i, passenger_id in enumerate(flight.waitlist, 1):
                        passenger = self.passengers[passenger_id]
                        f.write(f"{i}. {passenger.get_name()}\n")
                
                f.write("="*60 + "\n")
                
            print(f"Flight manifest generated: {filename}")
            
        except Exception as e:
            print(f"Error generating manifest: {e}")
    
    def generate_daily_sales_report(self):
        try:
            today = datetime.now().strftime('%Y-%m-%d')
            filename = f"daily_sales_report_{today}.txt"
            
            total_sales = 0
            total_bookings = 0
            flight_sales = {}
            
            for booking_id, booking in self.bookings.items():
                if booking.status == "Confirmed":
                    booking_date = booking.booking_date.strftime('%Y-%m-%d')
                    if booking_date == today:
                        total_sales += booking.get_total_price()
                        total_bookings += 1
                        
                        flight_num = booking.flight.flight_number
                        if flight_num not in flight_sales:
                            flight_sales[flight_num] = {'count': 0, 'revenue': 0}
                        flight_sales[flight_num]['count'] += 1
                        flight_sales[flight_num]['revenue'] += booking.get_total_price()
            
            with open(filename, 'w') as f:
                f.write("="*50 + "\n")
                f.write(f"    DAILY SALES REPORT - {today}\n")
                f.write("="*50 + "\n")
                f.write(f"Total Bookings: {total_bookings}\n")
                f.write(f"Total Revenue: Rs. {total_sales}\n")
                f.write("\nFLIGHT WISE BREAKDOWN:\n")
                f.write("-"*50 + "\n")
                
                for flight_num, data in flight_sales.items():
                    f.write(f"{flight_num}: {data['count']} bookings, Rs. {data['revenue']}\n")
                
                f.write("="*50 + "\n")
                
            print(f"Daily sales report generated: {filename}")
            
        except Exception as e:
            print(f"Error generating sales report: {e}")
    
    def display_available_flights(self):
        print("\n" + "="*80)
        print("                    AVAILABLE FLIGHTS")
        print("="*80)
        for flight_num, flight in self.flights.items():
            print(f"Flight: {flight_num} | {flight.departure} → {flight.destination}")
            print(f"Time: {flight.departure_time} | Price: Rs.{flight.get_final_price()}")
            print(f"Available Seats: {len(flight.available_seats)}/{flight.total_seats}")
            print("-"*80)

# Main Program
def main():
    print("Welcome to Airline Reservation System!")
    
    # Initialize system
    system = AirlineReservationSystem()
    system.load_sample_data()
    
    while True:
        print("\n" + "="*50)
        print("         AIRLINE RESERVATION SYSTEM")
        print("="*50)
        print("1. View Available Flights")
        print("2. Make a Booking")
        print("3. Cancel Booking")
        print("4. Generate Flight Manifest")
        print("5. Generate Daily Sales Report")
        print("6. Exit")
        print("-"*50)
        
        try:
            choice = input("Enter your choice (1-6): ")
            
            if choice == '1':
                system.display_available_flights()
                
            elif choice == '2':
                print("\nMAKE A BOOKING")
                print("-"*30)
                passenger_id = input("Enter Passenger ID (P001-P004): ")
                flight_number = input("Enter Flight Number: ")
                seat_choice = input("Enter seat number (or press Enter for auto-assign): ")
                
                seat_number = None if seat_choice == '' else int(seat_choice)
                system.create_booking(passenger_id, flight_number, seat_number)
                
            elif choice == '3':
                print("\nCANCEL BOOKING")
                print("-"*30)
                booking_id = input("Enter Booking ID: ")
                system.cancel_booking(booking_id)
                
            elif choice == '4':
                print("\nGENERATE FLIGHT MANIFEST")
                print("-"*30)
                flight_number = input("Enter Flight Number: ")
                system.generate_flight_manifest(flight_number)
                
            elif choice == '5':
                system.generate_daily_sales_report()
                
            elif choice == '6':
                print("Thank you for using Airline Reservation System!")
                break
                
            else:
                print("Invalid choice! Please enter 1-6.")
                
        except Exception as e:
            print(f"An error occurred: {e}")
            print("Please try again.")

if __name__ == "__main__":
    main()