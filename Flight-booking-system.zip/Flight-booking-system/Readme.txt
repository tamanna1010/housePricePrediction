How to Run the Program
1.	Make sure you have Python installed on your computer
2.	Save the main program as airline_reservation_system.py
3.	Save the sample data files as flights.json and passengers.csv
4.	Open terminal/command prompt and navigate to the folder
5.	Run: python airline_reservation_system.py

Features Implemented
1. Inheritance
•	Base class Flight with subclasses DomesticFlight and InternationalFlight
•	Different pricing for international flights (extra Rs. 150 fee)
2. Encapsulation
•	Passenger class has private attributes (using __ prefix)
•	Getter and setter methods to access private data
3. Composition
•	Booking class contains Passenger and Flight objects
•	Shows "has-a" relationship
4. Exception Handling
•	Custom OverbookingError exception
•	Handles invalid flight numbers and seat requests
•	Try-catch blocks throughout the code
5. File Operations
•	Generates boarding passes in tickets/ folder
•	Creates flight manifests in manifests/ folder
•	Maintains bookings.log file
•	Generates daily sales reports

Sample Test Scenarios
1.	Make a booking: Use passenger P001-P008 with flights AI101, 6E202, AI301, EK501
2.	Test overbooking: Try to book more seats than available
3.	Cancel booking: Cancel and see waitlist functionality
4.	Generate manifest: Check passenger list for any flight
5.	Sales report: View daily booking statistics

File Structure After Running
project_folder/
├── airline_reservation_system.py
├── flights.json
├── passengers.csv
├── bookings.log
├── daily_sales_report_YYYY-MM-DD.txt
├── tickets/
│   ├── BK1000.txt
│   └── BK1001.txt
└── manifests/
    ├── manifest_AI101.txt
    └── manifest_6E202.txt
